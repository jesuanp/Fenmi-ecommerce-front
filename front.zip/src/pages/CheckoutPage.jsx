import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import useCart from '@/stores/cart';
import useUI from '@/stores/ui';
import settingsApi from '@/services/settings';
import { orderApi } from '@/services/orders';
import { paymentApi, savePendingPayment, clearPendingPayment, readPendingPayment } from '@/services/payments';
import { addressApi } from '@/services/addresses';
import { money } from '@/services/settings';
import useAuth from '@/stores/auth';
import { isOptionalPostalCodeValid, normalizeSavedPostalCode } from '@/utils/postalCode';
import { CHECKOUT_PROFILE_FIELDS, CHECKOUT_ADDRESS_FIELDS, fillEmptyCheckoutFields } from '@/utils/checkoutAutofill';
import { checkoutFingerprint, decideWompiRetry } from '@/utils/checkoutRetry';
import { comparePendingCheckout, canRequestStaleRelease } from '@/utils/pendingCheckoutSync';
import { isWompiWidgetVisible, watchWompiWidgetClose } from '@/utils/wompiWidget';
import { loadWompiWidget } from '@/utils/loadWompi';
import { buildWompiWebCheckoutUrl, shouldUseWompiWebCheckout, shouldPreferHostedWompiCheckout } from '@/utils/wompiWebCheckout';
import { needsWompiContract, canConfirmCheckoutPayment } from '@/utils/colombiaCheckout';
import { deliveryMethodsForCheckout, FENMI_DELIVERY_GROUPS, selectedDeliveryGroup, deliveryMethodFor, changeDeliveryGroup } from '@/utils/colombiaDeliverySetup';
import { COLOMBIA_DEPARTMENTS } from '@/utils/colombiaDepartments';

const STEPS = ['Datos y método de entrega', 'Pago o confirmación'];

const WDEBUG = import.meta.env.DEV;
const wlog = (...a) => { if (WDEBUG) console.log('[wompi:fe]', ...a); };
const werr = (...a) => { if (WDEBUG) console.error('[wompi:fe]', ...a); };

// Diagnóstico del entorno de Wompi en el navegador.
function wompiEnvReport() {
  if (!WDEBUG || shouldUseWompiWebCheckout()) return;
  const script = document.querySelector('script[src*="checkout.wompi.co"]');
  console.log('[wompi:fe] === DIAGNÓSTICO ENTORNO WOMPI ===', {
    'script widget.js presente en DOM': script ? script.src : false,
    'typeof window.WidgetCheckout': typeof window.WidgetCheckout,
    'typeof window.WompiCheckout': typeof window.WompiCheckout,
    'typeof window.WompiButton': typeof window.WompiButton,
    'globals relacionados': Object.keys(window).filter((k) => /wompi|checkout/i.test(k))
  });
}

export default function CheckoutPage() {
  const cart = useCart();
  const auth = useAuth();
  const ui = useUI();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);

  useEffect(() => {
    cart.hydrate();
  }, []);
  const [shippingMethods, setShippingMethods] = useState(() => deliveryMethodsForCheckout(null));
  const [shippingMethodsLoading, setShippingMethodsLoading] = useState(true);
  const [shippingLoadError, setShippingLoadError] = useState('');
  const [colombiaShipping, setColombiaShipping] = useState(null);
  const [quoteError, setQuoteError] = useState('');
  const [quote, setQuote] = useState(null);
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [quoteRefresh, setQuoteRefresh] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [paymentPending, setPaymentPending] = useState(false);
  const [previousCheckout, setPreviousCheckout] = useState(null);
  const [recoveringCheckout, setRecoveringCheckout] = useState(false);
  const submittingRef = useRef(false);
  const watcherRef = useRef(null);

  useEffect(() => () => watcherRef.current?.(), []);

  const stopWatchingWidget = () => {
    watcherRef.current?.();
    watcherRef.current = null;
  };

  // Rescate de intentos anteriores: en una instalación antigua el carrito pudo
  // quedar CONVERTED al abrir Wompi. Antes de tocar nada preguntamos a la API
  // qué pasó con ese
  // pago: si sigue en vuelo no se descarta (el cliente puede estar en el
  // banco con un PSE abierto), si falló le devolvemos los artículos.
  const rescueRef = useRef(false);
  useEffect(() => {
    if (rescueRef.current) return;
    if (!cart.hydrated || cart.items.length > 0) return;
    const pending = readPendingPayment();
    if (!pending?.orderId) return;

    rescueRef.current = true;
    (async () => {
      let status = 'PENDING';
      try {
        const r = await paymentApi.verify('wompi', pending.orderNumber);
        status = String(r?.status || 'PENDING').toUpperCase();
      } catch {
        status = 'UNKNOWN';
      }
      wlog('rescate: estado del pago pendiente =', status);

      if (status === 'APPROVED') {
        clearPendingPayment();
        navigate(`/checkout/success/${pending.orderNumber}`, { replace: true });
        return;
      }
      if (status === 'PENDING' || status === 'UNKNOWN') {
        await cart.hydrate();
        ui.showToast('El pago anterior sigue sin confirmación. Los productos deben permanecer en tu carrito.');
        return;
      }

      try {
        await orderApi.abandon(pending.orderId);
        clearPendingPayment();
        await cart.hydrate();
        wlog('rescate: pedido liberado de vuelta al carrito');
      } catch (e) {
        werr('no se pudo rescatar el pedido pendiente', e?.message);
        navigate('/cart', { replace: true });
      }
    })();
  }, [cart.hydrated, cart.items.length]);

  // Inicial: si carrito vacío → redirect.
  useEffect(() => {
    wompiEnvReport();
    if (rescueRef.current) return;
    if (cart.hydrated && cart.items.length === 0) {
      navigate('/cart', { replace: true });
    }
  }, [cart.hydrated, cart.items.length]);

  const [paymentConfig, setPaymentConfig] = useState(null);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptPrivacy, setAcceptPrivacy] = useState(false);

  // Cargar config de tienda (envío) y de pago (Wompi) por separado.
  useEffect(() => {
    settingsApi
      .get()
      .then((s) => {
        const colombia = s.shipping?.colombia;
        // Las cinco modalidades se muestran con su disponibilidad real.
        // Nunca usar el precio heredado de 'Envio nacional' ($12.000).
        setColombiaShipping(colombia || null);
        setShippingMethods(deliveryMethodsForCheckout(colombia));
        setShippingLoadError('');
        setShippingMethodsLoading(false);
      })
      .catch(() => {
        ui.showToast('No se pudo verificar la configuración de entregas');
        setShippingLoadError('No pudimos verificar las modalidades en el servidor. Por seguridad, están bloqueadas hasta recuperar la conexión.');
        setColombiaShipping(null);
        setShippingMethods(deliveryMethodsForCheckout(null));
        setShippingMethodsLoading(false);
      });

    // /payments/config trae publicKey + enlaces a los contratos que Wompi
    // exige aceptar (Habeas Data).
    paymentApi
      .getConfig()
      .then((c) => {
        wlog('config desde /api/payments/config →', c);
        setPaymentConfig(c);
      })
      .catch((e) => {
        werr('falló /api/payments/config →', e.response?.status, e.response?.data);
        setPaymentConfig({ provider: 'manual' });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Dirección guardada del usuario (para no volver a escribirla).
  const [savedAddress, setSavedAddress] = useState(null);
  const [usingSaved, setUsingSaved] = useState(false);
  const [invalidSavedPostalCode, setInvalidSavedPostalCode] = useState(false);

  // Cargar la última dirección guardada si hay sesión.
  useEffect(() => {
    let vivo = true;
    if (!auth.user?.id) return undefined;
    addressApi
      .list()
      .then((rows) => {
        if (!vivo || !Array.isArray(rows) || rows.length === 0) return;
        setSavedAddress(rows[0]);
        setUsingSaved(true);
        wlog('dirección guardada cargada →', rows[0]);
      })
      .catch(() => {
        /* invitado o sin direcciones: seguimos con el formulario vacío */
      });
    return () => {
      vivo = false;
    };
  }, [auth.user?.id]);

  const defaults = auth.user || {};
  const touchedFieldsRef = useRef(new Set());

  const [form, setForm] = useState({
    firstName: defaults.firstName || '',
    lastName: defaults.lastName || '',
    email: defaults.email || '',
    phone: defaults.phone || '',
    recipient: '',
    line1: '',
    line2: '',
    city: '',
    state: '',
    postal_code: '',
    country: 'CO',
    instructions: '',
    methodId: '',
    locationId: ''
  });

  useEffect(() => {
    if (!auth.checked || auth.status !== 'authenticated' || !auth.user?.id) return;
    setForm((current) => fillEmptyCheckoutFields(current, auth.user, CHECKOUT_PROFILE_FIELDS, touchedFieldsRef.current));
  }, [auth.checked, auth.status, auth.user?.id, auth.user?.firstName, auth.user?.lastName, auth.user?.email, auth.user?.phone]);

  const set = (k, v) => {
    touchedFieldsRef.current.add(k);
    if (k === 'postal_code') setInvalidSavedPostalCode(false);
    if (k === 'methodId' || ['city', 'state', 'line1', 'locationId'].includes(k)) { setQuote(null); setQuoteError(''); }
    setForm((f) => k === 'methodId' ? { ...f, methodId: v, locationId: '' } : { ...f, [k]: v });
  };

  // Aplicar la dirección guardada a los campos de envío.
  useEffect(() => {
    if (!usingSaved || !savedAddress) return;
    const savedCode = String(savedAddress.postal_code ?? '').trim();
    setInvalidSavedPostalCode(Boolean(savedCode && !isOptionalPostalCodeValid(savedCode)));
    setForm((current) => fillEmptyCheckoutFields(
      current,
      { ...savedAddress, postal_code: normalizeSavedPostalCode(savedAddress.postal_code) },
      CHECKOUT_ADDRESS_FIELDS,
      touchedFieldsRef.current
    ));
  }, [usingSaved, savedAddress]);

  const discardSavedAddress = () => {
    setUsingSaved(false);
    setInvalidSavedPostalCode(false);
    setForm((f) => ({
      ...f,
      recipient: '',
      line1: '',
      line2: '',
      city: '',
      state: '',
      postal_code: '',
      instructions: ''
    }));
  };

  const wompiMode = paymentConfig?.provider === 'wompi';
  const requiresWompi = needsWompiContract(paymentConfig?.provider, form.methodId);
  // El método de pago NO se elige aquí: el widget de Wompi lo pide al cliente
  // dentro de su propia pasarela. Solo se exige aceptar los contratos.
  const contractsAccepted = canConfirmCheckoutPayment(paymentConfig?.provider, form.methodId, acceptTerms, acceptPrivacy);
  const wompiReady = contractsAccepted;

  useEffect(() => {
    if (!requiresWompi || !cart.hydrated || cart.items.length === 0) return undefined;
    let active = true;
    orderApi.pendingCheckout()
      .then((result) => { if (active) setPreviousCheckout(result); })
      .catch(() => {});
    return () => { active = false; };
  }, [requiresWompi, cart.hydrated, cart.items.length]);

  const selectedMethod = shippingMethods.find((method) => String(method.id) === String(form.methodId));
  const selectedGroup = selectedDeliveryGroup(form.methodId);
  const selectionNeedsPoint = selectedMethod?.mode === 'OFFICE';
  const isMeeting = selectedMethod?.mode === 'MEETING';
  const addressNeeded = selectedMethod?.mode === 'HOME';
  const needsLiveRate = selectedMethod?.rateMode === 'LIVE_AVEONLINE';
  const selectedLocation = null; // Retiro en sucursal: próximamente. El encuentro lo escribe el comprador.
  const checkoutShipping = {
    recipient: form.recipient.trim() || `${form.firstName.trim()} ${form.lastName.trim()}`.trim(), phone: form.phone.trim(), line1: form.line1.trim(),
    line2: form.line2?.trim() || null, city: form.city.trim(), state: form.state.trim(),
    postal_code: form.postal_code?.trim() || null, country: 'CO',
    locationId: selectionNeedsPoint ? form.locationId : null,
    instructions: form.instructions?.trim() || null
  };

  useEffect(() => {
    if (!form.methodId || cart.items.length === 0 || !selectedMethod?.available) { setQuote(null); setQuoteLoading(false); setQuoteError(''); return undefined; }
    if (selectionNeedsPoint && (!selectedLocation || selectedLocation.readyForCheckout === false)) { setQuote(null); setQuoteLoading(false); return undefined; }
    if (isMeeting && form.line1.trim().length < 8) { setQuote(null); setQuoteLoading(false); return undefined; }
    if (addressNeeded && (!form.city.trim() || !form.state.trim() || form.line1.trim().length < 4 || !/^(\+57\s?)?\d{10}$/.test(form.phone.trim()))) { setQuote(null); setQuoteLoading(false); return undefined; }
    let active = true;
    setQuote(null);
    setQuoteLoading(true);
    const timer = setTimeout(() => {
      setQuoteError('');
      orderApi.quote(cart.subtotal(), form.methodId, checkoutShipping)
        .then((result) => { if (active) { setQuote(result); setQuoteError(''); } })
        .catch((error) => { if (active) { setQuote(null); setQuoteError(error.response?.data?.error?.message || 'No se pudo obtener la tarifa real. No se cobrará un precio estimado.'); } })
        .finally(() => { if (active) setQuoteLoading(false); });
    }, 500);
    return () => { active = false; clearTimeout(timer); };
  }, [form.methodId, form.locationId, selectedMethod?.available, selectedLocation?.id, form.city, form.state, form.line1, form.recipient, form.firstName, form.lastName, form.phone, cart.items.length, cart.subtotal(), cart.items.map((item) => `${item.variantId}-${item.quantity}`).join('|'), quoteRefresh]);

  const infoValid = form.firstName.trim().length > 1 && form.lastName.trim().length > 1 && form.email.trim().includes('@') && /^(\+57\s?)?\d{10}$/.test(form.phone.trim());
  const postalCodeValid = isOptionalPostalCodeValid(form.postal_code);
  const addrValid = isMeeting ? form.line1.trim().length >= 8 : (addressNeeded && form.line1.trim().length >= 4 && form.city.trim().length > 1 && form.state.trim().length > 1 && postalCodeValid);
  const quoteExpired = needsLiveRate && quote?.quoteExpiresAt && Date.parse(quote.quoteExpiresAt) <= Date.now();
  const paymentReadyForMethod = isMeeting || (addressNeeded && wompiMode);
  const methodValid = !!selectedMethod && selectedMethod.available !== false && selectedMethod.mode !== 'OFFICE' && paymentReadyForMethod && !quoteLoading && !quoteExpired && quote?.methodId === form.methodId;

  useEffect(() => {
    if (!needsLiveRate || !quote?.quoteExpiresAt) return undefined;
    const expiresAt = Date.parse(quote.quoteExpiresAt);
    if (!Number.isFinite(expiresAt)) return undefined;
    const timer = window.setTimeout(() => {
      setQuote(null);
      setQuoteRefresh((value) => value + 1);
    }, Math.max(250, expiresAt - Date.now()));
    return () => window.clearTimeout(timer);
  }, [needsLiveRate, quote?.quoteExpiresAt]);

  useEffect(() => {
    if (!needsLiveRate) return undefined;
    const refreshOnReturn = () => {
      if (document.visibilityState === 'visible') setQuoteRefresh((value) => value + 1);
    };
    window.addEventListener('focus', refreshOnReturn);
    return () => window.removeEventListener('focus', refreshOnReturn);
  }, [needsLiveRate]);

  const shippingDiscount = cart.coupon?.type === 'FREE_SHIPPING' && quote ? Number(quote.cost || 0) : 0;
  const displayTotal = Math.max(0, Number(cart.subtotal() || 0) + Number(quote?.cost || 0) - Number(cart.discount || 0) - shippingDiscount);

  const showPreviousCheckout = async () => {
    const result = await orderApi.pendingCheckout();
    setPreviousCheckout(result);
    return result;
  };

  const openWompiCheckout = async (order, widget, fingerprint) => {
    if (!widget?.publicKey || !widget?.integritySignature) {
      throw new Error('Configuración de pago incompleta.');
    }
    const hostedCheckoutUrl = buildWompiWebCheckoutUrl(widget);

    savePendingPayment({
      orderId: order.id,
      orderNumber: order.orderNumber,
      provider: 'wompi',
      widget,
      fingerprint
    });

    setPreviousCheckout(null);
    const useHostedCheckout = shouldPreferHostedWompiCheckout(import.meta.env.VITE_WOMPI_DESKTOP_WIDGET === 'true');
    if (useHostedCheckout) {
      window.location.assign(hostedCheckoutUrl);
      return;
    }

    try {
      await loadWompiWidget();
      if (typeof window.WidgetCheckout !== 'function') {
        throw new Error('No se pudo abrir el widget de Wompi.');
      }

      const checkout = new window.WidgetCheckout({
        publicKey: widget.publicKey,
        currency: widget.currency,
        amountInCents: widget.amountInCents,
        reference: widget.reference,
        redirectUrl: widget.redirectUrl,
        signature: { integrity: widget.integritySignature }
      });

      setPaymentPending(true);
      watcherRef.current = watchWompiWidgetClose(() => {
        watcherRef.current = null;
        setPaymentPending(false);
      });

      checkout.open((result) => {
        stopWatchingWidget();
        setPaymentPending(false);
        const tx = result?.transaction || {};
        const status = String(tx.status || '').toUpperCase();
        wlog('callback del widget →', { status });
        if (!status) {
          ui.showToast('Pago no confirmado. Tus productos permanecen en el carrito.');
          return;
        }
        navigate(`/checkout/success/${order.orderNumber}`, {
          state: { orderId: order.id, provider: 'wompi', wompiTx: tx }
        });
      });
    } catch (error) {
      stopWatchingWidget();
      setPaymentPending(false);
      werr('widget no disponible; usando Web Checkout', error.message);
      ui.showToast('El widget no pudo abrirse. Te llevamos a la pasarela completa de Wompi.');
      window.location.assign(hostedCheckoutUrl);
    }
  };

  const resumePreviousCheckout = async () => {
    if (!previousCheckout || recoveringCheckout) return;
    setRecoveringCheckout(true);
    try {
      if (previousCheckout.hasProviderReference) {
        const verification = await paymentApi.verify('wompi', previousCheckout.orderNumber);
        if (verification.confirmed || verification.status === 'APPROVED') {
          navigate(`/checkout/success/${previousCheckout.orderNumber}`, { state: { provider: 'wompi' } });
          return;
        }
        if (verification.verification === 'UNAVAILABLE') {
          ui.showToast('No se pudo comprobar el pago anterior con Wompi. Intenta nuevamente más tarde.');
          return;
        }
      }
      const result = await orderApi.resumePending(previousCheckout.orderId);
      await openWompiCheckout(
        { id: previousCheckout.orderId, orderNumber: previousCheckout.orderNumber },
        result.widget,
        readPendingPayment()?.orderId === previousCheckout.orderId ? readPendingPayment()?.fingerprint : null
      );
    } catch (err) {
      ui.showToast(err.response?.data?.error?.message || err.message || 'No se pudo recuperar el pago anterior.');
      await showPreviousCheckout().catch(() => {});
    } finally {
      setRecoveringCheckout(false);
    }
  };

  const releasePreviousCheckout = async () => {
    if (!previousCheckout || recoveringCheckout) return;
    const accepted = window.confirm(previousCheckout.paymentKind === 'in_person' ? '¿Quieres cancelar el encuentro presencial anterior? Los productos seguirán en el carrito.' : previousCheckout.paymentKind === 'shipping_quote' ? '¿Quieres cancelar la solicitud de envío anterior? Los productos seguirán en tu carrito.' : '¿Quieres descartar el pedido anterior? Comprobaremos que Wompi no tenga un pago aprobado ni en proceso. Los productos seguirán en el carrito.');
    if (!accepted) return;
    setRecoveringCheckout(true);
    try {
      await orderApi.releasePending(previousCheckout.orderId);
      if (readPendingPayment()?.orderId === previousCheckout.orderId) clearPendingPayment();
      setPreviousCheckout(null);
      await cart.hydrate();
      ui.showToast('Intento anterior liberado. Comprueba tus datos y vuelve a pagar.');
      setStep(0);
    } catch (err) {
      ui.showToast(err.response?.data?.error?.message || 'No se pudo liberar el intento. Comprueba el estado del pago.');
      await showPreviousCheckout().catch(() => {});
    } finally {
      setRecoveringCheckout(false);
    }
  };

  const submitOrder = async () => {
    if (!methodValid) {
      setStep(0);
      setQuoteRefresh((value) => value + 1);
      ui.showToast(selectedMethod?.available === false ? (selectedMethod.unavailableReason || 'Esta modalidad aún no puede confirmarse.') : 'La tarifa de envío venció o cambió. Revisa el importe actualizado antes de pagar.');
      return;
    }
    if (submittingRef.current) return;
    if (requiresWompi && paymentPending && isWompiWidgetVisible()) {
      ui.showToast('La pasarela de Wompi todavía está abierta. Ciérrala antes de intentar nuevamente.');
      return;
    }
    if (addressNeeded && !postalCodeValid) {
      setStep(0);
      ui.showToast('El código postal debe tener 6 dígitos, o puedes dejarlo vacío.');
      return;
    }
    submittingRef.current = true;
    stopWatchingWidget();
    setPaymentPending(false);
    setSubmitting(true);
    let createdOrderId = null;
    let paymentInitiated = false;
    try {
      const orderPayload = {
        customer: {
          firstName: form.firstName.trim(),
          lastName: form.lastName.trim(),
          email: form.email.trim(),
          phone: form.phone.trim()
        },
        shipping: checkoutShipping,
        methodId: form.methodId,
        expectedShippingCost: quote?.cost
      };
      const fingerprint = checkoutFingerprint({
        items: cart.items,
        ...orderPayload,
        coupon: cart.coupon,
        discount: cart.discount,
        total: cart.total
      });
      let order = null;
      let savedWidget = null;

      if (requiresWompi) {
        const pending = readPendingPayment();
        if (pending?.orderId && pending?.orderNumber && pending.provider === 'wompi') {
          const serverPending = await orderApi.pendingCheckout();
          const relation = comparePendingCheckout(pending, serverPending);
          if (relation === 'DIFFERENT') {
            setPreviousCheckout(serverPending);
            setStep(1);
            ui.showToast('Tu carrito tiene otro intento pendiente. Revisa la compra anterior antes de continuar.');
            return;
          }
          if (relation === 'NO_SERVER') {
            const verification = await paymentApi.verify('wompi', pending.orderNumber);
            if (verification?.confirmed || verification?.status === 'APPROVED') {
              navigate(`/checkout/success/${pending.orderNumber}`, { replace: true });
              return;
            }
            if (canRequestStaleRelease(verification)) {
              await orderApi.releasePending(pending.orderId);
              clearPendingPayment();
              setPreviousCheckout(null);
              await cart.hydrate();
              ui.showToast('El intento anterior ya estaba cancelado. Puedes iniciar un pago nuevo.');
            } else {
              ui.showToast('El intento anterior no aparece en el carrito actual, pero su pago no está confirmado. No abriremos otro cobro hasta verificarlo.');
              return;
            }
          } else if (pending.fingerprint === fingerprint) {
            const status = await paymentApi.verify('wompi', pending.orderNumber);
            const action = decideWompiRetry(pending, fingerprint, status?.status);
            if (action === 'APPROVED') {
              navigate(`/checkout/success/${pending.orderNumber}`, { replace: true });
              return;
            }
            if (action === 'VERIFY') {
              ui.showToast('No pudimos verificar el pago anterior. Intenta de nuevo en unos momentos.');
              return;
            }
            if (action === 'RESTART') {
              await orderApi.releasePending(pending.orderId);
              clearPendingPayment();
              await cart.hydrate();
            } else if (action === 'REUSE') {
              order = { id: pending.orderId, orderNumber: pending.orderNumber };
              const retry = await orderApi.resumePending(pending.orderId);
              savedWidget = retry.widget;
            }
          } else {
            const previous = await paymentApi.verify('wompi', pending.orderNumber);
            if (previous.confirmed || previous.status === 'APPROVED') {
              navigate(`/checkout/success/${pending.orderNumber}`, { replace: true });
              return;
            }
            if (['DECLINED', 'FAILED', 'VOIDED'].includes(previous.status)) {
              await orderApi.releasePending(pending.orderId);
              clearPendingPayment();
              await cart.hydrate();
            } else {
              await showPreviousCheckout();
              ui.showToast('Encontramos un intento anterior. Puedes reanudarlo o comprobar si es posible descartarlo.');
              return;
            }
          }
        }
      }

      if (!order) {
        order = await orderApi.create(orderPayload);
        createdOrderId = order.id;
      }

      if (selectedMethod?.mode === 'MEETING') {
        ui.showToast('Solicitud de encuentro registrada. Pagarás directamente al vendedor cuando recibas el producto.');
        navigate(`/checkout/meeting/${order.orderNumber}`, { state: { orderId: order.id } });
        return;
      }

      if (requiresWompi) {
        const pay = savedWidget ? null : await paymentApi.create(order.id);
        const widget = savedWidget || pay?.widget;
        paymentInitiated = true;
        await openWompiCheckout(order, widget, fingerprint);
        return;
      }
      // Pago manual sin pedido visible en la cuenta hasta su aprobación.
      // El pedido queda PENDING_PAYMENT y el cliente sube
      // la captura del comprobante (Nequi / Bancolombia) en la página de éxito.
      ui.showToast('Solicitud de pago creada. El carrito se conserva hasta aprobarse el pago.');
      await cart.hydrate();
      navigate(`/checkout/success/${order.orderNumber}`, {
        state: { orderId: order.id, provider: 'manual' }
      });
    } catch (err) {
      // Si el pedido se creó pero el pago falló, lo abandonamos para que el
      // carrito del cliente vuelva a tener sus artículos y pueda reintentar.
      if (createdOrderId && !paymentInitiated) {
        try {
          await orderApi.releasePending(createdOrderId);
          if (readPendingPayment()?.orderId === createdOrderId) clearPendingPayment();
          await cart.hydrate();
        } catch {
          /* noop: si no se puede revertir, al menos avisamos */
        }
      }

      werr('ERROR COMPLETO en submitOrder →', {
        message: err.message,
        status: err.response?.status,
        code: err.response?.data?.error?.code,
        messageApi: err.response?.data?.error?.message,
        details: err.response?.data?.error?.details,
        body: err.response?.data,
        configUrl: err.config?.url
      });

      if (paymentInitiated) await showPreviousCheckout().catch(() => {});
      const e = err.response?.data?.error || {};
      if (e.code === 'CHECKOUT_PENDING_ORDER') {
        await showPreviousCheckout().catch(() => {});
        setStep(1);
        ui.showToast('Encontramos un pedido anterior. Revisa las opciones para continuar de forma segura.');
        return;
      }
      if (e.code === 'CHECKOUT_PENDING_NOT_FOUND') {
        await showPreviousCheckout().catch(() => {});
        ui.showToast('El intento guardado cambió de estado. Revisa el carrito y consulta el pago anterior antes de reintentar.');
        return;
      }
      const details = Array.isArray(e.details) ? e.details : [];
      const list = details
        .map((d) => `${(d.path || d.field || []).join('.')}: ${d.message}`)
        .join(' · ');
      if (e.code === 'SHIPPING_RATE_CHANGED') {
        setQuote(null);
        setStep(0);
        setQuoteRefresh((value) => value + 1);
        ui.showToast('La tarifa de transporte cambió. Se volverá a cotizar antes de continuar; todavía no se realizó ningún cobro.');
      } else {
        ui.showToast(list || e.message || err.message || 'Error al crear el pedido');
      }
      if (err.response?.data?.error?.code === 'INSUFFICIENT_STOCK') {
        await cart.hydrate();
      }
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  return (
    <div className="container checkout-container">
      <h1 className="page-title" style={{ marginBottom: 8 }}>
        Finalizar compra
      </h1>
      <CheckoutSteps current={step} steps={STEPS} />

      {requiresWompi && previousCheckout && (
        <section className="checkout-recovery" role="region" aria-label="Intento de pago anterior">
          <div className="checkout-recovery-info">
            <strong>Hay una compra anterior sin confirmar</strong>
            <p>
              Referencia <b>{previousCheckout.orderNumber}</b> · {previousCheckout.paymentKind === 'shipping_quote' ? 'Flete pendiente de confirmar; todavía no hay total final.' : <>Importe <b>{money(previousCheckout.amount)}</b>.</>}
              El pedido anterior puede tener productos o datos de envío diferentes de los que ves ahora.
            </p>
            {previousCheckout.items?.length > 0 && (
              <p className="checkout-recovery-items">
                {previousCheckout.items.map((item) => `${item.quantity} × ${item.name}`).join(' · ')}
              </p>
            )}
            <p>{previousCheckout.paymentKind === 'shipping_quote'
              ? 'Recibimos una solicitud de envío a domicilio. Puedes consultar su estado o cancelarla si ya no la necesitas.'
              : !previousCheckout.canResume
              ? 'Este intento pertenece a un carrito anterior o ya venció. Revisa su estado antes de iniciar otro.'
              : previousCheckout.paymentKind === 'in_person'
              ? 'Tienes un encuentro presencial anterior todavía pendiente. Puedes consultarlo o cancelar la solicitud si ya no lo necesitas.'
              : previousCheckout.hasProviderReference
              ? 'No hemos marcado este pedido como pagado. Comprueba su estado o recupera el pago anterior.'
              : 'El intento quedó registrado antes de abrir Wompi. Puedes reabrirlo o liberarlo tras verificar que no haya un cobro.'}</p>
          </div>
          <div className="checkout-recovery-actions">
            {previousCheckout.paymentKind === 'shipping_quote' && <button type="button" className="btn lime" onClick={() => navigate(`/checkout/shipping/${previousCheckout.orderNumber}`)}>Ver solicitud de envío</button>}
            {previousCheckout.paymentKind !== 'in_person' && previousCheckout.paymentKind !== 'shipping_quote' && <button type="button" className="btn lime" disabled={recoveringCheckout || !previousCheckout.canResume} onClick={resumePreviousCheckout}>
              {recoveringCheckout ? 'Comprobando…' : 'Reabrir pago anterior'}
            </button>}
            <button type="button" className="btn outline" disabled={recoveringCheckout} onClick={releasePreviousCheckout}>
              {previousCheckout.paymentKind === 'in_person' ? 'Cancelar encuentro anterior' : previousCheckout.paymentKind === 'shipping_quote' ? 'Cancelar solicitud de envío' : 'Descartar intento anterior'}
            </button>
            {previousCheckout.hasProviderReference && (
              <button type="button" className="text-link checkout-recovery-link" onClick={() => navigate(`/checkout/success/${previousCheckout.orderNumber}`, { state: { provider: 'wompi' } })}>
                Comprobar estado del pago
              </button>
            )}
          </div>
        </section>
      )}

      <div className="checkout-layout">
        {/* ── Stepper content ── */}
        <div className="checkout-main">
          {step === 0 && (
            <div className="checkout-step">
              <div className="checkout-step-copy">
                <h2>Datos del cliente y entrega</h2>
                <p>Indica dónde deseas recibir tu compra. Puedes solicitar el pedido aunque el transporte requiera una cotización posterior.</p>
              </div>
              <div className="checkout-card">
                <div className="checkout-card-head"><div><h3>Información de contacto</h3><p>Te enviaremos novedades de la entrega a estos datos.</p></div></div>
                {!auth.checked && <p className="checkout-note">Recuperando datos de tu cuenta…</p>}
                <div className="checkout-grid">
                  <Field label="Nombre" value={form.firstName} onChange={(v) => set('firstName', v)} placeholder="Tu nombre" autoComplete="given-name" required />
                  <Field label="Apellido" value={form.lastName} onChange={(v) => set('lastName', v)} placeholder="Tu apellido" autoComplete="family-name" required />
                  <Field label="Correo" type="email" value={form.email} onChange={(v) => set('email', v)} placeholder="correo@ejemplo.com" autoComplete="email" required />
                  <Field label="Celular colombiano" value={form.phone} onChange={(v) => set('phone', v)} placeholder="3001234567" autoComplete="tel" inputMode="tel" required />
                </div>
              </div>

              <div className="checkout-card checkout-methods">
                <div className="checkout-card-head"><div>
                  <h3>¿Cómo quieres recibir tu pedido?</h3>
                  <p>Elige un encuentro para pagar al recibir, o el envío a la dirección de tu casa.</p>
                </div></div>
                {shippingMethodsLoading && <p role="status">Comprobando servicios de entrega…</p>}
                {!shippingMethodsLoading && shippingLoadError && <p role="alert" className="shipping-quote-error">{shippingLoadError}</p>}
                <div className="checkout-delivery-groups" role="radiogroup" aria-label="Cómo quieres recibir tu pedido">
                  {FENMI_DELIVERY_GROUPS.map((group) => <label key={group.id} className="ship-option checkout-delivery-group">
                    <input type="radio" name="delivery-group" value={group.id} checked={selectedGroup === group.id} onChange={() => set('methodId', changeDeliveryGroup(group.id, form.methodId))} />
                    <div><strong>{group.name}</strong><span>{group.description}</span></div>
                  </label>)}
                </div>
                {selectedGroup && selectedGroup !== 'meeting' && <fieldset className="checkout-delivery-preference">
                  <legend>¿Dónde quieres recibir tu pedido?</legend>
                  <label className="ship-option">
                    <input type="radio" name="delivery-place" value="HOME" checked={selectedMethod?.mode === 'HOME'} onChange={() => set('methodId', deliveryMethodFor(selectedGroup, 'HOME'))} />
                    <div><strong>En mi casa</strong><span>Indicaré la dirección y el municipio de destino.</span></div>
                  </label>
                  <label className="ship-option" aria-disabled="true" style={{ opacity: 0.6, cursor: 'not-allowed' }}>
                    <input type="radio" name="delivery-place" value="OFFICE" disabled checked={false} />
                    <div><strong>Recoger en una sucursal · Próximamente</strong><span>Esta opción aún no está habilitada.</span></div>
                  </label>
                </fieldset>}
                {selectedMethod?.available === false && !shippingMethodsLoading && <p className="shipping-quote-error" role="status">
                  Puedes elegir esta modalidad, pero aún no puedes confirmar el pedido: {selectedMethod.unavailableReason || 'FENMI debe habilitar el servicio y verificar la entrega.'}
                </p>}
                {selectedGroup && <p className="shipping-muted">
                  {selectedGroup === 'meeting'
                    ? 'Escribe el lugar donde prefieres encontrarte con el vendedor. FENMI coordinará contigo antes de entregar el producto. Paga en persona al recibirlo.'
                    : 'Escribe tu dirección y municipio. Si la agencia no devuelve una tarifa, registraremos tu solicitud sin cobrar hasta confirmar el costo.'}
                </p>}
              </div>

              {selectedMethod && <div className="checkout-card">
                <div className="checkout-card-head"><div>
                  <h3>{selectedMethod.mode === 'MEETING' ? 'Entrega presencial' : selectedMethod.mode === 'OFFICE' ? 'Recogida en sucursal' : 'Dirección de envío'}</h3>
                  <p>{selectedMethod.mode === 'MEETING' ? 'Escribe dónde te gustaría encontrarte con el vendedor. Confirmaremos el sitio contigo antes de entregar.' : selectedMethod.mode === 'OFFICE' ? 'Próximamente estará disponible.' : 'Escribe la dirección donde quieres recibir tu compra.'}</p>
                </div></div>
                {isMeeting && <Field label="¿Dónde te gustaría encontrarte con el vendedor?" value={form.line1} onChange={(v) => set('line1', v)} placeholder="Ej. Entrada principal del centro comercial, barrio y referencia" required className="field-span-2" />}
                {addressNeeded && <>
                  {usingSaved && savedAddress && <div className="checkout-banner"><span>Usamos tu última dirección guardada.</span><button type="button" className="text-link checkout-banner-action" onClick={discardSavedAddress}>Usar otra</button></div>}
                  <div className="checkout-grid">
                    <Field label="Dirección completa" value={form.line1} onChange={(v) => set('line1', v)} placeholder="Calle, carrera, número" autoComplete="shipping address-line1" required className="field-span-2" />
                    <Field label="Apartamento o complemento (opcional)" value={form.line2} onChange={(v) => set('line2', v)} placeholder="Apto, casa, torre, interior" autoComplete="shipping address-line2" className="field-span-2" />
                    <Field label="Ciudad o municipio" value={form.city} onChange={(v) => set('city', v)} placeholder="Ej. Barranquilla" autoComplete="shipping address-level2" required />
                    <label className="checkout-field"><span>Departamento</span><select className="field" value={form.state} onChange={(e) => set('state', e.target.value)} autoComplete="shipping address-level1" required><option value="">Selecciona un departamento</option>{COLOMBIA_DEPARTMENTS.map((department) => <option key={department} value={department}>{department}</option>)}</select></label>
                    <Field label="Código postal (opcional)" value={form.postal_code} onChange={(v) => set('postal_code', v)} inputMode="numeric" placeholder="Ej. 050001" autoComplete="shipping postal-code" hint="Si lo escribes, debe tener 6 dígitos." error={!postalCodeValid ? 'Escribe los 6 dígitos o deja el campo vacío.' : ''} />
                  </div>
                  {invalidSavedPostalCode && <p role="status" className="checkout-note">La dirección guardada tenía un código postal inválido y lo dejamos vacío.</p>}
                </>}
                <label className="checkout-field"><span>Indicaciones adicionales (opcional)</span><textarea className="field checkout-textarea" rows={3} value={form.instructions} onChange={(e) => set('instructions', e.target.value)} placeholder="Horario, indicaciones de entrega o datos del encuentro" /></label>
                {quoteLoading && <p className="shipping-quote-confirmed" role="status">{isMeeting ? 'Preparando solicitud de encuentro…' : 'Verificando disponibilidad de envío…'}</p>}
                {quoteError && <p className="shipping-quote-error" role="alert">{quoteError}</p>}
                {addressNeeded && paymentConfig && !wompiMode && <p className="shipping-quote-error" role="alert">La entrega a domicilio requiere Wompi. El administrador debe configurar la pasarela antes de aceptar este tipo de pedido.</p>}
                {quote && <p className="shipping-quote-confirmed">{quote.mode === 'MEETING' ? 'Encuentro presencial · el producto se paga al recibirlo y no se abre Wompi.' : quote.tariffSource === 'AVEONLINE_LIVE_QUOTE' ? `Tarifa de ${selectedMethod?.name}: ${money(quote.quotedCarrierCost)}${quote.free ? ' (FENMI asume el flete)' : ''}${quote.deliveryDays ? ` · aproximadamente ${quote.deliveryDays} día(s)` : ''}. Cotización sujeta a las condiciones de la transportadora.` : `Tarifa de envío registrada por FENMI: ${quote.free ? 'sin costo para ti' : money(quote.cost)}.`}</p>}
              </div>}
            </div>
          )}

          {step === 1 && (
            <div className="checkout-step">
              <h2>Confirmar pedido</h2>
              {selectedMethod?.mode === 'MEETING' ? (
                <div className="checkout-meeting-notice">
                  <h3>Encuentro con el vendedor</h3>
                  <p>No se realizará ningún cobro por Wompi ahora. FENMI recibirá el lugar que indicaste y coordinará contigo el encuentro.</p>
                  <p><strong>Importante:</strong> paga únicamente cuando recibas el producto y el vendedor confirme el encuentro. La compra solo aparecerá como pagada después de registrar la entrega y el dinero recibido.</p>
                  <p>Lugar propuesto: <strong>{form.line1}</strong></p>
                </div>
              ) : wompiMode ? (
                <>
                  <p style={{ color: 'var(--mid)', fontSize: 13, marginBottom: 14 }}>
                    Irás a la página segura de Wompi a pantalla completa para evitar bloqueos de carga.
                    Allí eliges cómo pagar
                    (los métodos que tu comercio tenga habilitados).
                  </p>
                  {paymentConfig?.sandbox && (
                    <p
                      style={{
                        background: 'var(--lime-light)',
                        color: 'var(--teal-dark)',
                        padding: '8px 14px',
                        borderRadius: 8,
                        fontSize: 12,
                        fontWeight: 600
                      }}
                    >
                      Modo sandbox — usa las tarjetas de prueba de Wompi
                    </p>
                  )}

                  {/* Wompi exige aceptación explícita de los contratos
                      (Ley 1581 de Habeas Data). Sin ambas casillas no se puede pagar. */}
                  <div
                    style={{
                      marginTop: 18,
                      padding: 14,
                      border: '1px solid var(--border)',
                      borderRadius: 10,
                      display: 'grid',
                      gap: 10
                    }}
                  >
                    <p style={{ fontSize: 12, color: 'var(--mid)', margin: 0 }}>
                      Wompi requiere tu aceptación explícita de sus contratos para procesar el pago.
                    </p>
                    <label className="check-row" style={{ alignItems: 'flex-start' }}>
                      <input
                        type="checkbox"
                        checked={acceptTerms}
                        onChange={(e) => setAcceptTerms(e.target.checked)}
                      />
                      <span style={{ fontSize: 13 }}>
                        He leído y acepto los{' '}
                        <a
                          href={paymentConfig?.termsUrl || 'https://wompi.com/assets/downloadble/reglamento-Usuarios-Colombia.pdf'}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: 'var(--teal)', textDecoration: 'underline' }}
                        >
                          términos y condiciones de Wompi
                        </a>
                        .
                      </span>
                    </label>
                    <label className="check-row" style={{ alignItems: 'flex-start' }}>
                      <input
                        type="checkbox"
                        checked={acceptPrivacy}
                        onChange={(e) => setAcceptPrivacy(e.target.checked)}
                      />
                      <span style={{ fontSize: 13 }}>
                        He leído y acepto la{' '}
                        <a
                          href={paymentConfig?.privacyUrl || 'https://wompi.com/assets/downloadble/autorizacion-tratamiento-datos-personales.pdf'}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: 'var(--teal)', textDecoration: 'underline' }}
                        >
                          autorización de tratamiento de datos personales
                        </a>
                        .
                      </span>
                    </label>
                  </div>
                </>
              ) : (
                <p style={{ color: 'var(--mid)', fontSize: 13 }}>
                  Al confirmar crearás tu pedido. El pago se procesa en el siguiente paso.
                </p>
              )}
            </div>
          )}

          <div className="checkout-nav">
            {step > 0 && (
              <button className="btn outline" onClick={() => setStep(step - 1)}>
                ← Volver
              </button>
            )}
            {step < 1 ? (
              <button
                className="btn"
                disabled={
                  (step === 0 && !(infoValid && addrValid && methodValid))
                }
                onClick={() => setStep(step + 1)}
              >
                Continuar →
              </button>
            ) : (
              <button
                className="btn lime block"
                disabled={submitting || recoveringCheckout || Boolean(requiresWompi && previousCheckout) || (requiresWompi && !wompiReady)}
                onClick={submitOrder}
              >
                {submitting
                  ? 'Creando pedido…'
                  : selectedMethod?.mode === 'MEETING'
                  ? 'Solicitar encuentro · pagar al recibir'
                  : requiresWompi
                  ? 'Pagar con Wompi'
                  : 'Realizar pedido'}
              </button>
            )}
          </div>
        </div>

        {/* ── Resumen lateral ── */}
        <div className="checkout-summary">
          <h3>Resumen de tu compra</h3>
          {cart.items.map((item) => (
            <div key={item.itemId} className="cs-line">
              <div>
                <strong>{item.name}</strong>
                <span>
                  {item.color} / {item.size} · x{item.quantity}
                </span>
              </div>
              <span>{money(item.subtotal)}</span>
            </div>
          ))}
          {selectedMethod && <p className="shipping-selected-summary">{selectedMethod.name}{selectedLocation ? ` · ${selectedLocation.name}` : ''}</p>}
          <div className="cs-totals">
            <div className="cs-row">
              <span>Subtotal</span>
              <span>{money(cart.subtotal())}</span>
            </div>
            {(cart.discount > 0 || shippingDiscount > 0) && (
              <div className="cs-row">
                <span>Descuento</span>
                <span style={{ color: 'var(--teal)' }}>−{money(Number(cart.discount || 0) + shippingDiscount)}</span>
              </div>
            )}
            <div className="cs-row">
              <span>Envío</span>
              <span>
                {quote ? (quote.free ? 'Sin costo' : money(quote.cost)) : 'Por confirmar'}
              </span>
            </div>
            <div className="cs-total">
              <span>Total</span>
              <strong>
                {money(displayTotal)}
              </strong>
            </div>
          </div>
          {paymentPending && wompiMode ? (
            <button
              type="button"
              className="text-link"
              style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
              onClick={() => navigate('/cart')}
            >
              ← Volver al carrito (pago sin confirmar)
            </button>
          ) : (
            <Link to="/cart" className="text-link">
              ← Volver al carrito
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  inputMode,
  placeholder = '',
  autoComplete,
  hint = '',
  error = '',
  required = false,
  className = ''
}) {
  return (
    <label className={`checkout-field ${className}`.trim()}>
      <span>
        {label}
        {required ? <em>*</em> : null}
      </span>
      <input
        className={`field ${error ? 'field-error' : ''}`.trim()}
        type={type}
        inputMode={inputMode}
        placeholder={placeholder}
        autoComplete={autoComplete}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      {hint && !error ? <small className="checkout-hint">{hint}</small> : null}
      {error ? <small role="alert" className="checkout-error">{error}</small> : null}
    </label>
  );
}

export function CheckoutSteps({ current, steps }) {
  return (
    <div className="checkout-steps">
      {steps.map((s, i) => (
        <div key={s} className={'cs-step' + (i <= current ? ' done' : '') + (i === current ? ' active' : '')}>
          <span>{i + 1}</span>
          {s}
        </div>
      ))}
    </div>
  );
}